import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
  
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

@MultipartConfig(fileSizeThreshold=1024*1024*10,    // 10 MB 
maxFileSize=1024*1024*50,          // 50 MB
maxRequestSize=1024*1024*100)      // 100 MB

public class FileUploadServlet extends HttpServlet {
	  
    private static final long serialVersionUID = 205242440643911308L;
     
    /**
     * Directory where uploaded files will be saved, its relative to
     * the web application directory.
     */
    private static final String UPLOAD_DIR = "uploads";
      
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException,NullPointerException {
          String fileName = null;
        String end[]={"xls"};
      
        for (Part part : request.getParts()) {
            fileName = getFileName(part);
            if(fileName.contains(end[0]))
            {
            	try
                {
                	Connection con;
                	String dbUrl = "jdbc:oracle:thin:@localhost:1521:xe";
                    Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
                    con=DriverManager.getConnection(dbUrl,"system","root");

                	String cmtpth="F:\\excel\\"+fileName;
                	
                    FileInputStream file = new FileInputStream(new File(cmtpth));
         
                    //Create Workbook instance holding reference to .xls file
                    HSSFWorkbook workbook=new HSSFWorkbook(file);
                    
                    //Get first/desired sheet from the workbook
                    HSSFSheet sheet=workbook.getSheetAt(0);
                    Row row;
                    //Iterate through each rows one by one
                	//System.out.println("above for loop");
                    	for(int i=1; i<=sheet.getLastRowNum(); i++)
                    	{
                        row = sheet.getRow(i); 
                        //System.out.println(row);
                        //int id = (int) row.getCell(0).getNumericCellValue();
                        //String name = row.getCell(1).getStringCellValue();
                       
                       
                        String  title=row.getCell(0).getStringCellValue();
                       String surname=row.getCell(1).getStringCellValue();
                		String firstname=row.getCell(2).getStringCellValue();
                		String middlename=row.getCell(3).getStringCellValue();
                		String institute=row.getCell(4).getStringCellValue();
String query="insert into STUDENTUPLOADDETAILS values('"+title+"','"+surname+"','"+firstname+"','"+middlename+"','"+institute+"')";

                	
Statement st=con.createStatement();

st.executeUpdate(query);
		           
		           System.out.println("Connection established for oracle");
                
                       
                        
                    }
                    file.close();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                     }
            else{
            	System.out.println("other");
                 	
            	
            }
            //part.write(uploadFilePath + File.separator + fileName);
        }
  
        request.setAttribute("message", fileName + " File uploaded successfully!");
        getServletContext().getRequestDispatcher("/response.jsp").forward(
                request, response);
    }
  
    /**
     * Utility method to get file name from HTTP header content-disposition
     */
    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        System.out.println("content-disposition header= "+contentDisp);
        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length()-1);
            }
        }
        return "";
    }
}
